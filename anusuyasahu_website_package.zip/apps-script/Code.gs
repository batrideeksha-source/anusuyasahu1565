const SHEET_NAME = "Events";
const PROP_FORM_URL = "FORM_URL";
const PROP_FORM_EDIT_URL = "FORM_EDIT_URL";
const PROP_TRIGGER_ID = "TRIGGER_ID";

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  sheet.clear();

  sheet.appendRow([
    "id",
    "section",
    "status",
    "title",
    "date",
    "description",
    "imageUrl",
    "linkUrl",
    "updatedAt"
  ]);

  const form = FormApp.create("Anusuya Sahu Event Manager");
  form.setDescription(
    "Create, edit, or delete event cards for the website. For images, paste a direct image URL or add a File upload question titled 'Image File' if you want Google Drive uploads."
  );
  form.setCollectEmail(true);
  form.setAllowResponseEdits(true);
  form.setPublished(true);

  form.addMultipleChoiceItem()
    .setTitle("Action")
    .setChoiceValues(["Create", "Edit", "Delete"])
    .setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle("Section")
    .setChoiceValues(["upcoming", "gallery"])
    .setRequired(true);

  form.addTextItem()
    .setTitle("Event ID")
    .setHelpText("Leave blank for Create. Use an existing ID for Edit/Delete.")
    .setRequired(false);

  form.addTextItem()
    .setTitle("Title")
    .setRequired(false);

  form.addTextItem()
    .setTitle("Date")
    .setHelpText("Use YYYY-MM-DD or any display text you like.")
    .setRequired(false);

  form.addParagraphTextItem()
    .setTitle("Description")
    .setRequired(false);

  form.addTextItem()
    .setTitle("Image URL")
    .setHelpText("Paste a direct image link or a Google Drive share link.")
    .setRequired(false);

  form.addTextItem()
    .setTitle("Link URL")
    .setHelpText("Optional button link for the event card.")
    .setRequired(false);

  form.addParagraphTextItem()
    .setTitle("Notes")
    .setHelpText("Optional notes for edits or deletions.")
    .setRequired(false);

  PropertiesService.getScriptProperties().setProperties({
    [PROP_FORM_URL]: form.getPublishedUrl(),
    [PROP_FORM_EDIT_URL]: form.getEditUrl()
  }, true);

  removeExistingTriggers_();
  ScriptApp.newTrigger("onFormSubmit")
    .forForm(form)
    .onFormSubmit()
    .create();
}

function removeExistingTriggers_() {
  const props = PropertiesService.getScriptProperties();
  const triggerId = props.getProperty(PROP_TRIGGER_ID);
  if (!triggerId) return;

  const triggers = ScriptApp.getProjectTriggers();
  for (const trigger of triggers) {
    if (trigger.getUniqueId && trigger.getUniqueId() === triggerId) {
      ScriptApp.deleteTrigger(trigger);
    }
  }
}

function onFormSubmit(e) {
  const response = e.response;
  const data = readResponse_(response);
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const now = new Date();

  if (!sheet) throw new Error("Events sheet not found. Run setup() first.");

  const action = (data.Action || "").toLowerCase();
  const section = (data.Section || "upcoming").toLowerCase();
  const incomingId = normalizeId_(data["Event ID"] || data.Title || data.Description || "event");
  const title = safeString_(data.Title);
  const date = safeString_(data.Date);
  const description = safeString_(data.Description);
  const imageUrl = normalizeImageUrl_(data["Image URL"] || data["Image File"] || "");
  const linkUrl = safeString_(data["Link URL"]);
  const existingRow = findRowById_(sheet, incomingId);

  if (action === "delete") {
    if (existingRow > 0) {
      sheet.getRange(existingRow, 3).setValue("deleted");
      sheet.getRange(existingRow, 9).setValue(now.toISOString());
    }
    return;
  }

  const rowData = [
    incomingId,
    section,
    "active",
    title,
    date,
    description,
    imageUrl,
    linkUrl,
    now.toISOString()
  ];

  if (action === "edit" && existingRow > 0) {
    sheet.getRange(existingRow, 1, 1, rowData.length).setValues([rowData]);
  } else {
    sheet.appendRow(rowData);
  }
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) ? String(e.parameter.action).toLowerCase() : "list";
  if (action === "form") {
    return textOutput_({
      formUrl: PropertiesService.getScriptProperties().getProperty(PROP_FORM_URL) || "",
      editUrl: PropertiesService.getScriptProperties().getProperty(PROP_FORM_EDIT_URL) || ""
    });
  }

  if (action === "list") {
    return textOutput_({
      events: readEvents_()
    });
  }

  return textOutput_({
    ok: true,
    message: "Use ?action=list to get events or ?action=form to get form URLs."
  });
}

function readEvents_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return [];

  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values.shift();
  return values
    .map(row => rowToObject_(headers, row))
    .filter(item => String(item.status || "").toLowerCase() !== "deleted");
}

function rowToObject_(headers, row) {
  const obj = {};
  headers.forEach((header, i) => obj[header] = row[i]);
  return obj;
}

function findRowById_(sheet, id) {
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return -1;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]).trim() === String(id).trim()) return i + 1;
  }
  return -1;
}

function readResponse_(response) {
  const out = {};
  const itemResponses = response.getItemResponses();
  itemResponses.forEach(itemResponse => {
    const title = itemResponse.getItem().getTitle();
    const value = itemResponse.getResponse();
    out[title] = value;
  });
  return out;
}

function normalizeId_(text) {
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48) || ("event-" + Date.now());
}

function safeString_(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function normalizeImageUrl_(value) {
  if (Array.isArray(value) && value.length) {
    return driveFileUrl_(value[0]);
  }
  const text = safeString_(value);
  if (!text) return "";
  if (/^https?:\/\//i.test(text)) return text;
  if (/^drive:/i.test(text)) {
    const id = text.split(":").pop();
    return driveFileUrl_(id);
  }
  return text;
}

function driveFileUrl_(fileId) {
  const id = safeString_(fileId);
  if (!id) return "";
  return "https://drive.google.com/file/d/" + id + "/view";
}

function textOutput_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj, null, 2))
    .setMimeType(ContentService.MimeType.JSON);
}
